#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import time
from ctypes import cdll

if __name__ == '__main__':
    p = r'F:\Dll\x64\Debug\Dll.dll'
    dll = cdll.LoadLibrary(p)
    for i in range(10):
        dll.MoveTo2(500, 450)
        dll.LeftDown()
        time.sleep(0.1)
        dll.LeftUp()
    dll.Close()
