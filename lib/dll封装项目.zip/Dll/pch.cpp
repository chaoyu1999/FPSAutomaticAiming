﻿// pch.cpp: 与预编译标头对应的源文件

#include "pch.h"
#pragma comment (lib,"msdk.lib")
#include <iostream>
#include "msdk.h"

HDC const hDC = GetDC(NULL);
// 创建一个透明画刷
HBRUSH hBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
// 将画刷选入DC
HBRUSH hOldBrush = (HBRUSH)SelectObject(hDC, hBrush);

HANDLE m_hdl = M_Open(1);
int WINAPI LeftDown() {

	M_LeftDown(m_hdl);
	return 0;
}

int WINAPI LeftUp() {
;
	M_LeftUp(m_hdl);
	return 0;
}

int MoveTo2(int x,int y) {
	
	M_MoveTo2(m_hdl, x,y);
	return 0;
}

int Close() {
	M_Close(m_hdl);
	return 0;
}

int DrawRectangle(int x,int y,int w,int h,int r,int g, int b) {
	// 创建实线，宽度为1，红色的笔
	HPEN hPen = CreatePen(PS_SOLID, 4, RGB(r, g, b));
	// 将笔选入DC
	HPEN hOldPen = (HPEN)SelectObject(hDC, hPen);
    // 绘制矩形
    Rectangle(hDC, x, y, w, h);
    //InvalidateRect(0, NULL, TRUE);
    return 0;
}